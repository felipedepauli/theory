# Power Electronics

Description.
First of all, this is a project to learn packaging in python. But, the package is a collection of functions that calculates the important variables in power circuits:

    Rectifiers:
  
        - Get values from a halph wave rectifier
        - Get values from a whole wave rectifier

    Utils:

        - Plot waves
  
## Installation

Use the package manager [pip](https//pip.pypa.io/en/stable) to install package_name

```python
pip install power_electronics
```

## Author
Felipe Camargo de Pauli

## License
[MIT](https://choosealicense.com/licenses/mit)

