print(f'This is my app. Have fun here.')

def my_Function():
    print(f'This is amazing.')
    
my_Function()