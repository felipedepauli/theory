def pontoMedio():
    print(f"I'm the medium point retifier.")